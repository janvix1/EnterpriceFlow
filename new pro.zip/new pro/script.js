// DOM Elements
document.addEventListener('DOMContentLoaded', function() {
    // Check which page we're on
    const isLoginPage = document.querySelector('.login-body');
    const isDashboardPage = document.querySelector('.dashboard-body');

    // Set current date
    updateCurrentDate();

    // Login page functionality
    if (isLoginPage) {
        handleLoginPage();
    }

    // Dashboard page functionality
    if (isDashboardPage) {
        handleDashboardPage();
    }
});

// Update current date display
function updateCurrentDate() {
    const currentDateElement = document.getElementById('current-date');
    if (currentDateElement) {
        const now = new Date();
        const options = { year: 'numeric', month: 'long', day: 'numeric' };
        currentDateElement.textContent = now.toLocaleDateString('en-US', options);
    }
}

// Handle login page functionality
function handleLoginPage() {
    const loginForm = document.getElementById('loginForm');
    const togglePassword = document.querySelector('.toggle-password');
    const passwordInput = document.getElementById('password');
    
    // Toggle password visibility
    if (togglePassword) {
        togglePassword.addEventListener('click', function() {
            const type = passwordInput.getAttribute('type') === 'password' ? 'text' : 'password';
            passwordInput.setAttribute('type', type);
            this.classList.toggle('fa-eye');
            this.classList.toggle('fa-eye-slash');
        });
    }
    
    // Handle login form submission
    if (loginForm) {
        loginForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            const username = document.getElementById('username').value;
            const password = document.getElementById('password').value;
            
            // Simple validation
            if (username.trim() === '' || password.trim() === '') {
                showNotification('Please enter both username and password', 'error');
                return;
            }
            
            // Here you would typically make an API call to authenticate the user
            // For this demo, we'll just simulate a successful login
            
            showNotification('Login successful! Redirecting...', 'success');
            
            // Simulate loading
            setTimeout(function() {
                // Redirect to dashboard page
                window.location.href = 'index.html';
            }, 1500);
        });
    }
}

// Handle dashboard page functionality
function handleDashboardPage() {
    // Mobile menu toggle
    const menuToggle = document.querySelector('.menu-toggle');
    const sidebar = document.querySelector('.sidebar');
    
    if (menuToggle) {
        menuToggle.addEventListener('click', function() {
            sidebar.classList.toggle('open');
        });
    }
    
    // Handle refresh button
    const refreshBtn = document.querySelector('.refresh-btn');
    if (refreshBtn) {
        refreshBtn.addEventListener('click', function() {
            this.classList.add('rotating');
            showNotification('Refreshing dashboard data...', 'info');
            
            // Simulate data refresh
            setTimeout(() => {
                this.classList.remove('rotating');
                showNotification('Dashboard data updated!', 'success');
            }, 1500);
        });
    }
    
    // Handle theme toggle
    const themeToggle = document.querySelector('.theme-toggle');
    if (themeToggle) {
        themeToggle.addEventListener('click', function() {
            document.body.classList.toggle('dark-theme');
            
            const isDark = document.body.classList.contains('dark-theme');
            const icon = this.querySelector('i');
            
            if (isDark) {
                icon.classList.remove('fa-moon');
                icon.classList.add('fa-sun');
                localStorage.setItem('theme', 'dark');
                showNotification('Dark theme enabled', 'info');
            } else {
                icon.classList.remove('fa-sun');
                icon.classList.add('fa-moon');
                localStorage.setItem('theme', 'light');
                showNotification('Light theme enabled', 'info');
            }
        });
        
        // Check for saved theme preference
        const savedTheme = localStorage.getItem('theme');
        if (savedTheme === 'dark') {
            document.body.classList.add('dark-theme');
            const icon = themeToggle.querySelector('i');
            icon.classList.remove('fa-moon');
            icon.classList.add('fa-sun');
        }
    }
    
    // Initialize quick access cards
    initQuickAccessCards();
    
    // Initialize widget interactions
    initWidgetInteractions();
}

// Initialize quick access cards
function initQuickAccessCards() {
    const quickAccessCards = document.querySelectorAll('.quick-access-card');
    
    quickAccessCards.forEach(card => {
        card.addEventListener('click', function() {
            const id = this.id;
            const title = this.querySelector('h4').textContent;
            
            // Highlight the corresponding menu item
            const menuItems = document.querySelectorAll('.sidebar-menu li');
            menuItems.forEach(item => {
                item.classList.remove('active');
                if (item.querySelector('a').getAttribute('href') === '#' + id) {
                    item.classList.add('active');
                }
            });
            
            showNotification(`Navigating to ${title}`, 'info');
            
            // Here you would typically navigate to the specific section
            // or load different content
        });
    });
}

// Initialize widget interactions
function initWidgetInteractions() {
    // Widget action buttons
    const widgetActionBtns = document.querySelectorAll('.widget-actions button');
    widgetActionBtns.forEach(btn => {
        btn.addEventListener('click', function(e) {
            e.stopPropagation();
            const widgetTitle = this.closest('.widget-header').querySelector('h3').textContent.trim();
            
            // Create dropdown menu
            const dropdown = document.createElement('div');
            dropdown.className = 'widget-dropdown';
            dropdown.innerHTML = `
                <ul>
                    <li data-action="refresh">Refresh</li>
                    <li data-action="expand">Expand</li>
                    <li data-action="settings">Settings</li>
                </ul>
            `;
            
            // Position the dropdown
            const rect = this.getBoundingClientRect();
            dropdown.style.top = (rect.bottom + 5) + 'px';
            dropdown.style.right = (window.innerWidth - rect.right) + 'px';
            
            // Add to DOM
            document.body.appendChild(dropdown);
            
            // Handle dropdown item clicks
            dropdown.querySelectorAll('li').forEach(item => {
                item.addEventListener('click', function() {
                    const action = this.getAttribute('data-action');
                    handleWidgetAction(action, widgetTitle);
                    removeDropdown();
                });
            });
            
            // Close dropdown when clicking elsewhere
            document.addEventListener('click', removeDropdown);
            
            function removeDropdown() {
                document.removeEventListener('click', removeDropdown);
                if (dropdown.parentNode) {
                    dropdown.parentNode.removeChild(dropdown);
                }
            }
        });
    });
}

// Handle widget actions
function handleWidgetAction(action, widgetTitle) {
    switch (action) {
        case 'refresh':
            showNotification(`Refreshing ${widgetTitle} data...`, 'info');
            break;
        case 'expand':
            showNotification(`${widgetTitle} expanded to full view`, 'info');
            break;
        case 'settings':
            showNotification(`${widgetTitle} settings opened`, 'info');
            break;
    }
}

// Show notification
function showNotification(message, type = 'info') {
    // Create notification element
    const notification = document.createElement('div');
    notification.className = `notification ${type}`;
    notification.innerHTML = message;
    
    // Append to body
    document.body.appendChild(notification);
    
    // Show notification
    setTimeout(() => {
        notification.classList.add('show');
    }, 10);
    
    // Hide and remove notification
    setTimeout(() => {
        notification.classList.remove('show');
        setTimeout(() => {
            notification.remove();
        }, 300);
    }, 3000);
}

// Add CSS for notifications and additional elements
(function addDynamicStyles() {
    const style = document.createElement('style');
    style.textContent = `
        .notification {
            position: fixed;
            top: 20px;
            right: 20px;
            padding: 15px 20px;
            background-color: white;
            color: #333;
            border-radius: var(--radius);
            box-shadow: var(--shadow-lg);
            z-index: 1000;
            transform: translateX(120%);
            transition: transform 0.3s ease;
            max-width: 300px;
        }
        
        .notification.show {
            transform: translateX(0);
        }
        
        .notification.success {
            border-left: 4px solid var(--success-color);
        }
        
        .notification.error {
            border-left: 4px solid var(--danger-color);
        }
        
        .notification.info {
            border-left: 4px solid var(--info-color);
        }
        
        .rotating {
            animation: rotate 1.5s linear infinite;
        }
        
        @keyframes rotate {
            from { transform: rotate(0deg); }
            to { transform: rotate(360deg); }
        }
        
        .widget-dropdown {
            position: fixed;
            background: white;
            border-radius: var(--radius-sm);
            box-shadow: var(--shadow-lg);
            z-index: 1000;
            min-width: 150px;
            overflow: hidden;
        }
        
        .widget-dropdown ul {
            list-style: none;
            padding: 0;
            margin: 0;
        }
        
        .widget-dropdown li {
            padding: 10px 15px;
            font-size: 14px;
            cursor: pointer;
            transition: background 0.2s ease;
        }
        
        .widget-dropdown li:hover {
            background: var(--grey-light);
        }
        
        /* Dark Theme Styles */
        .dark-theme {
            background-color: #0f172a;
            color: #f1f5f9;
        }
        
        .dark-theme .sidebar,
        .dark-theme header,
        .dark-theme .widget,
        .dark-theme .quick-access-card,
        .dark-theme .empty-dashboard,
        .dark-theme .notification,
        .dark-theme .widget-dropdown {
            background-color: #1e293b;
            color: #f1f5f9;
        }
        
        .dark-theme .sidebar-menu ul li a,
        .dark-theme .widget-header h3,
        .dark-theme .quick-info h4,
        .dark-theme .timeline-content h4,
        .dark-theme .maintenance-details h4,
        .dark-theme .dashboard-greeting h2,
        .dark-theme .quick-access h3 {
            color: #f1f5f9;
        }
        
        .dark-theme .sidebar-header,
        .dark-theme .widget-header,
        .dark-theme .maintenance-item {
            border-color: #334155;
        }
        
        .dark-theme .sidebar-menu ul li a:hover {
            background-color: rgba(99, 102, 241, 0.2);
        }
        
        .dark-theme .refresh-btn,
        .dark-theme .theme-toggle {
            background-color: #334155;
            color: #94a3b8;
        }
        
        .dark-theme .timeline-progress,
        .dark-theme .circle-bg {
            background-color: #334155;
        }
    `;
    document.head.appendChild(style);
})(); 